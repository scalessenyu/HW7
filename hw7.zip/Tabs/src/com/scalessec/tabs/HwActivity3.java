package com.scalessec.tabs;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class HwActivity3 extends Activity {
   
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hw3);
    }
    
    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.options, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		TextView textView = (TextView)findViewById(R.id.textView);
		View bgView = (View)textView.getParent();
		
		switch (item.getItemId()) {
		case R.id.red:
			bgView.setBackgroundColor(Color.RED);
			return true;

		case R.id.yellow:
			bgView.setBackgroundColor(Color.YELLOW);
			return true;

		case R.id.green:
			bgView.setBackgroundColor(Color.GREEN);
			return true;

		case R.id.cyan:
			bgView.setBackgroundColor(Color.CYAN);
			return true;

		case R.id.blue:
			bgView.setBackgroundColor(Color.BLUE);
			return true;

		case R.id.magenta:
			bgView.setBackgroundColor(Color.MAGENTA);
			return true;

		case R.id.gray:
			bgView.setBackgroundColor(Color.GRAY);
			return true;

		case R.id.black:
			bgView.setBackgroundColor(Color.BLACK);
			return true;

		default:
			return super.onOptionsItemSelected(item);
		}
	}

    
}