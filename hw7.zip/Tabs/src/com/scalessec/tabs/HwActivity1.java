package com.scalessec.tabs;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.TextView;
import android.widget.Toast;

public class HwActivity1 extends Activity {
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	
    	//call the superclass's onCreate
        super.onCreate(savedInstanceState);
        
        //set the view defined in hw1.xml
        setContentView(R.layout.hw1);
        
        //get the message defined in strings.xml
        String message = getString(R.string.message);
        
        //display the message in a TextView
        TextView textView = (TextView)findViewById(R.id.textView);
        textView.setText(message);
        
        //display the message as Toast
        Toast toast = Toast.makeText(this, message + "\n\n(onCreate)", Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
        
        //display the message in the log
        Log.d("HW2", message);
        
    }
    
    @Override
    public void onResume() {
    	super.onResume();
    	
    	String message = getString(R.string.message);
    	
    	//display the message as Toast
        Toast toast = Toast.makeText(this, message + "\n\n(onResume)", Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }
    
}