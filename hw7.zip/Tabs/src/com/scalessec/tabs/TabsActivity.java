package com.scalessec.tabs;

import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.TabHost;

public class TabsActivity extends TabActivity {
    /** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		Resources res = getResources();
		Drawable starOrange = res.getDrawable(R.drawable.star_orange);
		Drawable starBlue = res.getDrawable(R.drawable.star_blue);
		Drawable starGreen = res.getDrawable(R.drawable.star_green);
		
		TabHost tabHost = getTabHost();	//method of TabActivity

		Intent intent = new Intent();
		intent.setClass(this, HwActivity1.class);
		TabHost.TabSpec spec = tabHost.newTabSpec("toast");
		spec.setIndicator("Toast" , starOrange);
		spec.setContent(intent);
		tabHost.addTab(spec);
		
		intent = new Intent();
		intent.setClass(this, HwActivity2.class);
		spec = tabHost.newTabSpec("threads");
		spec.setIndicator("Threads" , starBlue);
		spec.setContent(intent);
		tabHost.addTab(spec);
		
		intent = new Intent();
		intent.setClass(this, HwActivity3.class);
		spec = tabHost.newTabSpec("options");
		spec.setIndicator("Options" , starGreen);
		spec.setContent(intent);
		tabHost.addTab(spec);

		tabHost.setCurrentTab(0);

	}
	
	
}