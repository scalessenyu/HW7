package com.scalessec.tabs;

import java.util.Random;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class HwActivity2 extends Activity {
	
	//to keep track of the current disco ball frame
	private int currentFrame = 0;
	
	//references to the disco ball resources saved in an array of integers
	private int[] discoFrames = {
			R.drawable.disco_0,
			R.drawable.disco_1,
			R.drawable.disco_2,
			R.drawable.disco_3,
			R.drawable.disco_4,
			R.drawable.disco_5,
			R.drawable.disco_6,
			R.drawable.disco_7,
			R.drawable.disco_8,
			R.drawable.disco_9
	};
	
	/*
	 * Handler for the disco ball animation
	 */
	final Handler animationHandler = new Handler() {
		public void handleMessage(Message message) {
			currentFrame = (currentFrame < 9) ? ++currentFrame : 0;
			Log.d("Frame", Integer.toString(currentFrame));
			
			ImageView imageView = (ImageView)findViewById(R.id.imageView);
			imageView.setImageResource(discoFrames[currentFrame]);
		}
	};
	
	/*
	 * Handler for the background color
	 */
	final Handler colorHandler = new Handler() {
		public void handleMessage(Message message) {
			View imageView = findViewById(R.id.imageView);
			View bgView = (View)imageView.getParent().getParent(); //Is there a better way to do this?
	        
	        //generate a random color
	        Random random = new Random();
	        int r = random.nextInt(255);
	        int g = random.nextInt(255);
	        int b = random.nextInt(255);
	        
	        Log.d("Color", "r:" + Integer.toString(r) + " g:" + Integer.toString(g) + " b:" + Integer.toString(b));
	        
	        bgView.setBackgroundColor(Color.argb(255, r, g, b));
		}
	};

	//declare the threads (currently one time use only)
	final AnimationThread animationThread = new AnimationThread(animationHandler);
	final ColorThread colorThread = new ColorThread(colorHandler);
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hw2);
        
        final Button buttonBall = (Button)findViewById(R.id.buttonBall);
        final Button buttonColors = (Button)findViewById(R.id.buttonColors);
        
        //listener to start the rotation animation
		buttonBall.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if(!animationThread.isAlive()) { //start can only be called once in a thread's lifetime
					animationThread.start();
				}
			}
		});
		
		//listener to start the flashing colors
		buttonColors.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if(!colorThread.isAlive()) { //start can only be called once in a thread's lifetime
					colorThread.start();
				}
			}
		});

    }
}

/*
 * Thread for the rotation disco ball.
 */
final class AnimationThread extends Thread {
	Handler handler;
	private boolean stop; 

	AnimationThread(Handler h) {
		handler = h;
	}
   
	public void run() {
		for (;;) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				Log.e("AnimationThread", "Animation Thread Interrupted");
				return;
			}
			
			synchronized (this) {
		        if (stop) { //not implemented yet
		        	return;
		        }
		     }
			
			handler.sendEmptyMessage(NORM_PRIORITY); //send a blank message. logic is handled in the handler
		}
	}
	
	//TODO: implement stop & resume functionality
	public void forceStop() {
	    synchronized (this) {
	    	stop = true;
	    }
	} 
}

/*
 * Thread for the changing background color
 */
final class ColorThread extends Thread {
	Handler handler;
	private boolean stop; 
	
	ColorThread(Handler h) {
		handler = h;
	}
   
	public void run() {
		for (;;) {
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				Log.e("ColorThread", "Color Thread Interrupted");
				return;
			}
			
			synchronized (this) {
		        if (stop) { //not implemented yet
		        	return;
		        }
		     }
			
			handler.sendEmptyMessage(NORM_PRIORITY); //send a blank message. logic is handled in the handler
		}
	}
	
	//TODO: implement stop & resume functionality
	public void forceStop() {
	    synchronized (this) {
	    	stop = true;
	    }
	} 

}
